# VESPER — Netlify Deployment Guide

## What You'll Have
✅ **Permanent URL:** `https://your-site.netlify.app/VESPER.html`
✅ **Works anywhere:** Phone, desktop, any browser
✅ **Claude API working:** Fully functional with backend proxy
✅ **No setup required after deployment**

---

## Step 1: Download the Files
You have 3 files ready:
- `VESPER.html`
- `netlify.toml`
- `netlify/functions/claude.js`

Make sure the folder structure is:
```
vesper-netlify/
├── VESPER.html
├── netlify.toml
└── netlify/
    └── functions/
        └── claude.js
```

---

## Step 2: Create GitHub Repo (for Netlify to connect)

1. Go to **github.com** → Click **+** → **New repository**
2. **Repository name:** `vesper-netlify`
3. Keep it **Public**
4. Click **Create repository**

---

## Step 3: Upload Files to GitHub

1. Click **Add file** → **Upload files**
2. Drag all 3 files/folders into the box
3. Make sure folder structure matches above
4. Click **Commit changes**

GitHub should now have:
- `VESPER.html`
- `netlify.toml`
- `netlify/functions/claude.js`

---

## Step 4: Connect to Netlify

1. Go to **netlify.com** → Click **Sign up** (use GitHub account)
2. **Authorize Netlify** to access your GitHub
3. Click **Add new site** → **Import an existing project**
4. Select **GitHub**
5. Find **vesper-netlify** repo → Click it
6. Leave settings as default
7. Click **Deploy site**

**Wait 2-3 minutes...**

---

## Step 5: Your Site is Live!

Netlify will give you a URL like:
```
https://your-random-name.netlify.app
```

Your VESPER is at:
```
https://your-random-name.netlify.app/VESPER.html
```

---

## Step 6: Test It

1. Open the URL
2. Paste your **Anthropic API key**
3. Click **Connect**
4. Ask: **"What time is it?"**
5. Claude responds ✓

---

## How It Works

- **Browser → VESPER.html** (frontend)
- **VESPER.html → /.netlify/functions/claude** (backend)
- **Backend → Anthropic API** (with your API key)
- **Response comes back to VESPER**

The backend handles all the CORS issues. Your API key is safe (sent to backend, not exposed).

---

## Troubleshooting

**Still getting "Connection error"?**
- Hard refresh: **Ctrl+Shift+R** (Windows) or **Cmd+Shift+R** (Mac)
- Wait 5 minutes for Netlify to fully deploy
- Check API key format (must start with `sk-ant-`)

**URL doesn't work?**
- Make sure netlify.toml is in the root (same level as VESPER.html)
- Make sure claude.js is at `netlify/functions/claude.js`
- Check Netlify deployment logs for errors

---

## Done!

Your VESPER is now live, permanent, and fully functional.

Share the URL with anyone. Works worldwide.

